<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Login</title></head>
<body>
    <h1>POS Login</h1>
    <?php if ($error): ?><p><?= esc($error) ?></p><?php endif; ?>
    <form method="post">
        <?= csrf_field() ?>
        <label for="username">Username</label><br>
        <input id="username" name="username" required><br><br>
        <label for="password">Password</label><br>
        <input id="password" type="password" name="password" required><br><br>
        <button type="submit">Log In</button>
    </form>
</body>
</html>
