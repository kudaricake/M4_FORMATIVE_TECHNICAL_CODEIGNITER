<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login(): string
    {
        helper('form');
        $error = null;

        if ($this->request->getMethod() === 'post') {
            $username = trim((string) $this->request->getPost('username'));
            $password = (string) $this->request->getPost('password');
            $user = (new UserModel())->where('username', $username)->first();

            if ($user !== null && password_verify($password, $user['password'])) {
                session()->regenerate();
                session()->set([
                    'user_id' => $user['id'],
                    'username' => $user['username'],
                    'logged_in' => true,
                ]);

                return redirect()->to(base_url('accounts/customers'));
            }

            $error = 'Invalid username or password.';
        }

        return view('auth/login', ['error' => $error]);
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }
}
