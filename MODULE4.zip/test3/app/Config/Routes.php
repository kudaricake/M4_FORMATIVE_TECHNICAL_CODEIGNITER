<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('hello', 'Helloworld::index');
$routes->get('about', 'Pages::about');
$routes->get('products', 'Products::index');
$routes->get('products/(:num)', 'Products::show/$1');

$routes->match(['get', 'post'], 'login', 'Auth::login');
$routes->get('logout', 'Auth::logout');

$routes->get('accounts/customers', 'Accounts::customers', ['filter' => 'auth']);
$routes->get('accounts/users', 'Accounts::users', ['filter' => 'auth']);
$routes->match(['get', 'post'], 'customers/new', 'Accounts::newCustomer', ['filter' => 'auth']);
$routes->match(['get', 'post'], 'customers/edit/(:num)', 'Accounts::editCustomer/$1', ['filter' => 'auth']);
$routes->match(['get', 'post'], 'users/new', 'Accounts::newUser', ['filter' => 'auth']);
$routes->match(['get', 'post'], 'users/edit/(:num)', 'Accounts::editUser/$1', ['filter' => 'auth']);
