CREATE DATABASE IF NOT EXISTS pos_auth_database;
USE pos_auth_database;

CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    created_at DATETIME NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    avatar VARCHAR(255) NULL,
    created_at DATETIME NOT NULL
);

INSERT INTO customers (full_name, email, phone, created_at) VALUES
    ('Maria Santos', 'maria.santos@example.com', '09171234567', NOW()),
    ('Juan Dela Cruz', 'juan.delacruz@example.com', '09181234567', NOW()),
    ('Angela Reyes', 'angela.reyes@example.com', '09191234567', NOW()),
    ('Carlo Garcia', 'carlo.garcia@example.com', '09201234567', NOW()),
    ('Liza Bautista', 'liza.bautista@example.com', '09211234567', NOW());

-- Login password for these sample users: password123
INSERT INTO users (username, full_name, email, password, avatar, created_at) VALUES
    ('admin01', 'Ramon Admin', 'admin01@example.com', '$2y$10$7t/eziC64xoMTw4cnfj0b.VgKB0Hm7hSSJK6brENk9OAhozsp7GBe', NULL, NOW()),
    ('cashier01', 'Nina Cruz', 'cashier01@example.com', '$2y$10$7t/eziC64xoMTw4cnfj0b.VgKB0Hm7hSSJK6brENk9OAhozsp7GBe', NULL, NOW()),
    ('cashier02', 'Paolo Lim', 'cashier02@example.com', '$2y$10$7t/eziC64xoMTw4cnfj0b.VgKB0Hm7hSSJK6brENk9OAhozsp7GBe', NULL, NOW()),
    ('manager01', 'Grace Tan', 'manager01@example.com', '$2y$10$7t/eziC64xoMTw4cnfj0b.VgKB0Hm7hSSJK6brENk9OAhozsp7GBe', NULL, NOW()),
    ('cashier03', 'Owen Ramos', 'cashier03@example.com', '$2y$10$7t/eziC64xoMTw4cnfj0b.VgKB0Hm7hSSJK6brENk9OAhozsp7GBe', NULL, NOW());
